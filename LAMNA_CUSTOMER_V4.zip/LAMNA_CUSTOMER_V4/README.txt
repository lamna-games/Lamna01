لمنا — Customer V6

نسخة عميل محسنة للألعاب التفاعلية على Cloudflare Workers + Durable Objects.

أبرز ما في V6:
- 50 لعبة × 80 جولة = 4000 جولة.
- لا توجد أزرار لزيادة أو خفض النقاط يدويًا؛ احتساب النقاط مرتبط بنتيجة اللعب.
- تحكيم تلقائي في الألعاب الموضوعية، وتصويت/حسم جماعي في الألعاب الاجتماعية المناسبة.
- غرف لعب، كود مشاركة، QR، مزامنة لحظية، وإعادة اتصال.
- اختيار 10 / 20 / 40 / 80 جولة.
- آليات لمس فعلية للسحب والترتيب والحروف والألوان والظل والرسم الأعمى.
- شاشة نهاية: الفائز، الترتيب، إعادة اللعب، الرجوع لمتجر لمنا، وكود LAMNA10 لخصم 10%.
- شعار لمنا الرسمي مستخدم كهوية وعلامة مائية خفيفة دون تغطية السؤال أو الإجابات.
- لا تظهر للعميل تفاصيل تقنية مثل Cloudflare أو API أو server.js.
- كسر كاش V6 ودعم Safe Area للجوال.

النشر الحالي متوافق مع إعداد Cloudflare المرتبط بمستودع Lamna01: npm install ثم npm run deploy.


LAMNA V7 premium UX upgrade: per-game instructions, plus-only player entry, play mode choice, room lobby/readiness, improved setup, persistent prefs, premium finish, always-visible letter hunt, cache v7.
