
const G = window.LAMNA_GAME;
const $ = id => document.getElementById(id);
const qsa = s => [...document.querySelectorAll(s)];
let state = {
  idx:0, players:[], points:{}, current:0, seconds:G.seconds, timer:null,
  room:"", connected:false, rewardCount:0, lastRewardRound:0, secretVisible:false
};
let sse=null, audioCtx=null;

function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function rand(n){const a=new Uint32Array(1); crypto.getRandomValues(a); return a[0]%n}
function beep(type="point"){
  try{
    audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();
    const o=audioCtx.createOscillator(), g=audioCtx.createGain();
    const map={point:620,tick:350,reward:820,bad:180,start:500}; o.frequency.value=map[type]||500;
    g.gain.setValueAtTime(.07,audioCtx.currentTime); g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.13);
    o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+.14);
  }catch(e){}
}
function vibrate(p=[30]){navigator.vibrate?.(p)}
function toast(t){const x=$("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1500)}
function confetti(){
  const colors=["#0b3558","#d49a31","#1b7895","#9b6077","#27816f"];
  for(let i=0;i<28;i++){const e=document.createElement("i");e.className="confetti";e.style.left=rand(100)+"vw";e.style.top="-20px";e.style.background=colors[rand(colors.length)];e.style.animationDelay=(rand(250)/1000)+"s";document.body.appendChild(e);setTimeout(()=>e.remove(),1500)}
}
function show(id){qsa(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
function nextScreenToSetup(){
  buildNameInputs(G.minPlayers);
  show("setup");
}
function buildNameInputs(count){
  const c=Math.max(G.minPlayers,Math.min(G.maxPlayers,count));
  const grid=$("namegrid"); grid.innerHTML="";
  for(let i=0;i<c;i++){
    const box=document.createElement("div");box.className="namebox";
    box.innerHTML=`<label>اللاعب ${i+1}</label><input maxlength="18" autocomplete="name" inputmode="text" placeholder="الاسم الحقيقي" value="${state.players[i]?.name||""}">`;
    grid.appendChild(box);
  }
  $("addPlayer").style.display = c<G.maxPlayers ? "" : "none";
  $("removePlayer").style.display = c>G.minPlayers ? "" : "none";
}
function addPlayer(){buildNameInputs($("namegrid").children.length+1)}
function removePlayer(){buildNameInputs($("namegrid").children.length-1)}
function readPlayers(){
  const vals=[...$("namegrid").querySelectorAll("input")].map(x=>x.value.trim()).filter(Boolean);
  if(vals.length<G.minPlayers){toast(`أدخل ${G.minPlayers===G.maxPlayers?G.minPlayers:"على الأقل "+G.minPlayers} اسم`);beep("bad");return false}
  const norm=vals.map(v=>v.toLowerCase());
  if(new Set(norm).size!==norm.length){toast("لا تكرر نفس الاسم");beep("bad");return false}
  state.players=vals.map((name,i)=>({id:"p"+(i+1),name,team:i%2+1}));
  state.points=Object.fromEntries(state.players.map(p=>[p.id,0]));
  return true;
}
function createRoomCode(){return (G.num.toString().padStart(2,"0")+"-"+Math.random().toString(36).slice(2,6)).toUpperCase()}
async function checkBackend(){
  if(!navigator.onLine)return false;
  try{
    const r=await fetch("/api/health",{cache:"no-store"});
    return !!r.ok;
  }catch(e){
    return false;
  }
}
async function startGame(){
  if(!readPlayers())return;
  const ok=await checkBackend();
  if(!ok){
    toast("تعذر الاتصال، تحقق من الإنترنت وحاول مرة أخرى");
    return;
  }
  state.room=createRoomCode(); state.idx=0; state.current=0;
  await sync("start");
  connectEvents();
  renderScoreboard();
  show("game");
  beep("start"); loadRound();
}
async function sync(action="update",extra={}){
  try{
    const payload={room:state.room,game:G.num,action,
      state:{idx:state.idx,players:state.players,points:state.points,current:state.current,rewardCount:state.rewardCount,...extra}};
    await fetch("/api/state",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload)});
    state.connected=true;
  }catch(e){state.connected=false}
}
function connectEvents(){
  sse?.close();
  sse=new EventSource("/api/events?room="+encodeURIComponent(state.room));
  sse.onopen=()=>{};
  sse.onmessage=e=>{
    try{
      const msg=JSON.parse(e.data);
      if(msg?.source===window.__clientId)return;
      const st=msg?.state;if(!st)return;
      if(st.points)state.points=st.points;
      if(Number.isInteger(st.idx)&&st.idx!==state.idx){state.idx=st.idx;loadRound(false)}
      if(Number.isInteger(st.current))state.current=st.current;
      renderScoreboard();
    }catch(_){}
  };
}
function renderScoreboard(){
  const box=$("players"); box.innerHTML="";
  state.players.forEach((p,i)=>{
    const d=document.createElement("div");d.className="player"+(i===state.current?" turn":"");
    d.innerHTML=`<b>${esc(p.name)}</b><strong>${state.points[p.id]||0}</strong><button aria-label="أضف نقطة">+</button>`;
    d.querySelector("button").onclick=()=>addPoint(p.id,1,true);
    box.appendChild(d);
  })
}
async function addPoint(pid,delta=1,manual=false){
  state.points[pid]=Math.max(0,(state.points[pid]||0)+delta);
  renderScoreboard();beep(delta>=0?"point":"bad");vibrate(delta>=0?[35]:[80,40,80]);if(delta>0)confetti();
  if(manual)toast((state.players.find(p=>p.id===pid)?.name||"اللاعب")+" +"+delta);
  await sync("score");
  const total=Object.values(state.points).reduce((a,b)=>a+b,0);
  if(total>0 && total%10===0 && state.lastRewardRound!==state.idx+1) openReward("points");
}
function normalizeText(t){return t.replace(/^اسحب يمين إذا «صح» ويسار إذا «خرافة»: /,"").replace(/^القنبلة شغالة! /,"")}
function loadRound(fromLocal=true){
  clearInterval(state.timer);
  if(state.idx>=G.rounds.length){finish();return}
  const r=G.rounds[state.idx]; state.seconds=G.seconds;
  $("roundLabel").textContent=`${state.idx+1} / ${G.rounds.length}`;
  $("progress").style.width=((state.idx+1)/G.rounds.length*100)+"%";
  $("prompt").textContent=normalizeText(r.text);
  $("difficulty").textContent=`${r.difficulty} • ${G.mechanicLabel}`;
  $("timer").textContent=state.seconds;$("timer").classList.remove("danger");
  state.current=state.idx%state.players.length;
  renderScoreboard();renderInteraction(r);
  state.timer=setInterval(()=>{
    state.seconds--;$("timer").textContent=state.seconds;
    if(state.seconds<=5){$("timer").classList.add("danger");beep("tick")}
    if(state.seconds<=0){clearInterval(state.timer);beep("bad");vibrate([120,70,120])}
  },1000);
  if(r.card && (state.idx+1)%5===0 && state.lastRewardRound!==state.idx+1){
    state.lastRewardRound=state.idx+1;
    setTimeout(()=>openReward("round",r.card),250);
  }
  if(fromLocal)sync("round");
}
function setActions(a,b,fa,fb){
  $("a1").textContent=a;$("a2").textContent=b;$("a1").onclick=fa;$("a2").onclick=fb;
}
function nextRound(){
  clearInterval(state.timer);
  state.idx++; state.current=state.idx%state.players.length; loadRound(); 
}
function currentPlayer(){return state.players[state.current]}
function awardCurrent(n=1){addPoint(currentPlayer().id,n);setTimeout(nextRound,180)}
function parseTwoOptions(text){
  const m=text.match(/(?:اختر.*?:|واحد فقط:|اختيار إجباري:)?\s*(.*?)\s+أو\s+(.*?)(?:[؟?]|$)/);
  return m?[m[1],m[2]]:["الخيار الأول","الخيار الثاني"];
}
function renderInteraction(r){
  const x=$("interact");x.innerHTML="";
  const m=G.mechanic;
  if(["secret_reveal","outsider_role","spy_location","couple_secret_vote"].includes(m)){
    const d=document.createElement("div");d.className="secret";
    d.innerHTML=`<div><b>🔐 ${esc(currentPlayer().name)}</b><br><small>المعلومة تظهر لك وحدك — اضغط للكشف</small></div>`;
    let revealed=false; d.onclick=()=>{revealed=!revealed;d.innerHTML=revealed?`<div><b>${esc(r.text)}</b><br><small>اضغط لإخفاء ثم مرّر الجوال</small></div>`:`<div><b>🔐 ${esc(currentPlayer().name)}</b><br><small>اضغط للكشف</small></div>`};
    x.appendChild(d);setActions("مرّر للاعب التالي","ابدأ الجولة",()=>{state.current=(state.current+1)%state.players.length;renderScoreboard();renderInteraction(r)},()=>nextRound());return;
  }
  if(["count_keypad"].includes(m)){
    const k=document.createElement("div");k.className="keypad";for(let i=0;i<=9;i++){const b=document.createElement("button");b.textContent=i;b.onclick=()=>{toast("تم اختيار "+i);beep("point")};k.appendChild(b)}x.appendChild(k);setActions("ثبت الإجابة","التالي",()=>awardCurrent(1),nextRound);return;
  }
  if(["logic_input","couple_match","neighbor_match"].includes(m)){
    x.innerHTML=`<div class="inputanswer"><input id="answerInput" placeholder="اكتب الإجابة هنا"><button id="saveAnswer">ثبت</button></div>`;
    $("saveAnswer").onclick=()=>{const v=$("answerInput").value.trim();if(!v)return toast("اكتب الإجابة");toast("تم حفظ إجابة "+currentPlayer().name);beep("point")};
    setActions("نقطة للإجابة","التالي",()=>awardCurrent(1),nextRound);return;
  }
  if(["drag_order","precision_sort"].includes(m)){
    const tail=r.text.split(":").slice(1).join(":");const parts=tail.split("—").map(s=>s.trim()).filter(Boolean).slice(0,4);
    const row=document.createElement("div");row.className="dragrow";parts.forEach((p,i)=>{const c=document.createElement("div");c.className="chip";c.draggable=true;c.textContent=p;c.dataset.i=i;row.appendChild(c)});
    let drag=null;row.ondragstart=e=>drag=e.target;row.ondragover=e=>e.preventDefault();row.ondrop=e=>{e.preventDefault();if(drag&&e.target.classList.contains("chip"))row.insertBefore(drag,e.target)};
    x.appendChild(row);setActions("ثبت الترتيب","إعادة",()=>awardCurrent(1),()=>renderInteraction(r));return;
  }
  if(["dilemma_reason","couple_dilemma","head_to_head_compare","admit_or_dare"].includes(m)){
    const o=parseTwoOptions(r.text);x.innerHTML=`<div class="twosides"><button class="side" id="leftSide">${esc(o[0])}</button><button class="side" id="rightSide">${esc(o[1])}</button></div>`;
    $("leftSide").onclick=()=>{toast("اختيار: "+o[0]);beep("point")};$("rightSide").onclick=()=>{toast("اختيار: "+o[1]);beep("point")};
    setActions("نقطة بعد التبرير","التالي",()=>awardCurrent(1),nextRound);return;
  }
  if(m==="blind_draw"){
    x.innerHTML='<canvas class="canvas" id="drawCanvas"></canvas>';setupCanvas();
    setActions("نجح التخمين","امسح",()=>awardCurrent(1),clearCanvas);return;
  }
  if(["point_vote","travel_vote","who_said_it"].includes(m)){
    const row=document.createElement("div");row.className="dragrow";
    state.players.forEach(p=>{const b=document.createElement("button");b.className="chip";b.textContent=p.name;b.onclick=()=>{toast("تم التصويت لـ "+p.name);b.style.outline="2px solid var(--accent)"};row.appendChild(b)});x.appendChild(row);
    setActions("ثبت التصويت","التالي",nextRound,nextRound);return;
  }
  if(["buzzer_general","culture_buzzer","scavenger_race"].includes(m)){
    const row=document.createElement("div");row.className="dragrow";state.players.forEach(p=>{const b=document.createElement("button");b.className="chip";b.textContent="🔔 "+p.name;b.onclick=()=>{beep("reward");toast(p.name+" أول!");addPoint(p.id,1)};row.appendChild(b)});x.appendChild(row);
    setActions("التالي","إلغاء نقطة",nextRound,()=>{const p=currentPlayer();addPoint(p.id,-1)});return;
  }
  if(["progressive_identity","shadow_guess","place_clues","gift_clues","camp_riddle","night_riddle"].includes(m)){
    const btn=document.createElement("button");btn.className="side";btn.textContent="👀 اكشف تلميحًا";let c=0;btn.onclick=()=>{c++;toast("تلميح "+c+" — كل تلميح يقلل المكافأة");beep("tick")};x.appendChild(btn);
    setActions("تم التخمين", "التالي",()=>awardCurrent(Math.max(1,3-c)),nextRound);return;
  }
  if(["swipe_truth","lie_vote","tap_error","color_flash"].includes(m)){
    x.innerHTML='<div class="twosides"><button class="side" id="yesBtn">✅ الأول</button><button class="side" id="noBtn">❌ الثاني</button></div>';
    $("yesBtn").onclick=()=>{beep("point");toast("تم الاختيار")};$("noBtn").onclick=()=>{beep("bad");toast("تم الاختيار")};
    setActions("نقطة","التالي",()=>awardCurrent(1),nextRound);return;
  }
  if(m==="hunt_letter"){
    const b=document.createElement("button");b.className="chip";b.textContent="🔤 الحرف الهارب";b.style.position="relative";b.onclick=()=>{b.style.transform=`translate(${rand(120)-60}px,${rand(40)-20}px)`;beep("point")};x.appendChild(b);
    setActions("اصطدته","التالي",()=>awardCurrent(1),nextRound);return;
  }
  if(["bomb_math"].includes(m)){
    x.innerHTML='<div style="font-size:38px">💣</div>';setActions("أجبت قبل الصفر","انفجرت",()=>awardCurrent(2),()=>{beep("bad");nextRound()});return;
  }
  if(["basket_drag"].includes(m)){
    x.innerHTML='<div class="twosides"><div class="side">🧺 السلة الصح</div><div class="side">↔️ اسحب العنصر</div></div>';setActions("تصنيف صحيح","حاول مرة",()=>awardCurrent(1),()=>renderInteraction(r));return;
  }
  if(["charades_pass"].includes(m)){
    x.innerHTML=`<div class="secret"><div><b>🎭 ${esc(currentPlayer().name)}</b><br><small>شوف الكلمة لحالك ثم اقلب الجوال للفريق</small></div></div>`;
    setActions("الفريق خمن","مرّر الدور",()=>awardCurrent(2),()=>{state.current=(state.current+1)%state.players.length;renderScoreboard();nextRound()});return;
  }
  if(["story_chain","memory_turns","long_talk_turns"].includes(m)){
    x.innerHTML=`<div class="side">دور <b>${esc(currentPlayer().name)}</b> الآن</div>`;
    setActions("تمت الإضافة","الدور التالي",()=>{addPoint(currentPlayer().id,1);state.current=(state.current+1)%state.players.length;renderScoreboard();},nextRound);return;
  }
  if(["all_players_confirm","category_duel","table_challenge","survey_board","team_speed","duel_2v2"].includes(m)){
    x.innerHTML='<div class="twosides"><button class="side">فريق 1</button><button class="side">فريق 2</button></div>';
    setActions("فاز فريق 1","فاز فريق 2",()=>awardTeam(1),()=>awardTeam(2));return;
  }
  if(["motion_mirror","minute_object","no_laugh_elim","couple_task","accused_defense"].includes(m)){
    x.innerHTML=`<div class="side">🎯 الدور على ${esc(currentPlayer().name)}</div>`;
    setActions("نجح","لم ينجح",()=>awardCurrent(1),()=>{beep("bad");nextRound()});return;
  }
  x.innerHTML=`<div class="side">🎮 الدور على ${esc(currentPlayer().name)}</div>`;
  setActions("تم","التالي",()=>awardCurrent(1),nextRound);
}
function awardTeam(team){
  const ps=state.players.filter(p=>p.team===team);ps.forEach(p=>state.points[p.id]=(state.points[p.id]||0)+1);renderScoreboard();beep("point");confetti();sync("team");setTimeout(nextRound,180)
}
function setupCanvas(){
  const c=$("drawCanvas");if(!c)return;const r=c.getBoundingClientRect();c.width=Math.max(600,Math.floor(r.width*2));c.height=240;const ctx=c.getContext("2d");let d=false;
  const pos=e=>{const rr=c.getBoundingClientRect(),p=e.touches?e.touches[0]:e;return{x:(p.clientX-rr.left)*(c.width/rr.width),y:(p.clientY-rr.top)*(c.height/rr.height)}};
  const down=e=>{e.preventDefault();d=true;const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y)};const move=e=>{if(!d)return;e.preventDefault();const p=pos(e);ctx.lineWidth=9;ctx.lineCap="round";ctx.strokeStyle="#0b3558";ctx.lineTo(p.x,p.y);ctx.stroke()};const up=()=>d=false;
  c.addEventListener("touchstart",down,{passive:false});c.addEventListener("touchmove",move,{passive:false});c.addEventListener("touchend",up);c.addEventListener("mousedown",down);c.addEventListener("mousemove",move);window.addEventListener("mouseup",up)
}
function clearCanvas(){const c=$("drawCanvas");if(c)c.getContext("2d").clearRect(0,0,c.width,c.height)}
const outcomes=[
 {label:"نقاط مضاعفة",apply:()=>{const p=state.players[rand(state.players.length)];const add=Math.max(2,state.points[p.id]||1);state.points[p.id]+=add;return `${p.name} +${add} نقطة`}},
 {label:"مكافأة +3",apply:()=>{const p=state.players[rand(state.players.length)];state.points[p.id]+=3;return `${p.name} +3 نقاط`}},
 {label:"خصم نقطة",apply:()=>{const p=state.players[rand(state.players.length)];state.points[p.id]=Math.max(0,state.points[p.id]-1);return `${p.name} -1 نقطة`}},
 {label:"سرقة نقطتين",apply:()=>{if(state.players.length<2)return "تحدي إضافي بدل السرقة";let a=state.players[rand(state.players.length)],b=state.players[rand(state.players.length)];while(b.id===a.id)b=state.players[rand(state.players.length)];const n=Math.min(2,state.points[b.id]||0);state.points[b.id]-=n;state.points[a.id]+=n;return `${a.name} يسرق ${n} من ${b.name}`}},
 {label:"تبديل الأدوار",apply:()=>{state.current=(state.current+1)%state.players.length;return `الدور ينتقل إلى ${currentPlayer().name}`}},
 {label:"تحدي إضافي",apply:()=>`تحدي إضافي لـ ${currentPlayer().name}: نفّذ الجولة القادمة خلال نصف الوقت`}
];
function openReward(trigger,cardText=""){
  clearInterval(state.timer);const ov=$("rewardOverlay"), wheel=$("wheel"), chest=$("chest");
  const useWheel=rand(2)===0;wheel.style.display=useWheel?"block":"none";chest.style.display=useWheel?"none":"block";wheel.classList.remove("spin");void wheel.offsetWidth;if(useWheel)wheel.classList.add("spin");
  const o=outcomes[rand(outcomes.length)];state.rewardCount++;
  $("rewardTitle").textContent=useWheel?"عجلة لمنا":"صندوق لمنا";
  $("rewardText").textContent=cardText?cardText:"المفاجأة جاهزة…";
  ov.classList.add("show");beep("reward");vibrate([80,45,80]);confetti();
  setTimeout(()=>{const result=o.apply();$("rewardText").textContent=`${o.label}: ${result}`;renderScoreboard();sync("reward",{reward:o.label,result})},850)
}
function closeReward(){$("rewardOverlay").classList.remove("show");loadRound(false)}
function finish(){
  clearInterval(state.timer);sse?.close();
  const sorted=[...state.players].sort((a,b)=>(state.points[b.id]||0)-(state.points[a.id]||0));
  $("winner").textContent=sorted[0]?`🏆 ${sorted[0].name}`:"";
  $("finalScores").innerHTML=sorted.map(p=>`<div class="player"><b>${esc(p.name)}</b><strong>${state.points[p.id]||0}</strong></div>`).join("");
  show("finish");confetti();beep("reward");sync("finish")
}
window.addEventListener("online",()=>{});window.addEventListener("offline",()=>{});
window.addEventListener("DOMContentLoaded",()=>{$("gameTitle").textContent=G.title;$("bundleName").textContent=G.bundle;$("introTitle").textContent=G.title;$("introCue").textContent=G.cue;$("mechanicBadge").textContent=G.mechanicLabel;});
