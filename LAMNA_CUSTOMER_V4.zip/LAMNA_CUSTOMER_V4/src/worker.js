
const jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: jsonHeaders });
}

function roomName(value) {
  const room = String(value || "").trim().slice(0, 48);
  return /^[A-Z0-9_-]+$/i.test(room) ? room : "";
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/health") {
      return json({
        ok: true,
        backend: "cloudflare-workers-durable-objects",
        realtime: true,
        version: "v7",
        time: Date.now(),
      });
    }

    if (url.pathname === "/api/state" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "invalid_json" }, 400);
      }

      const room = roomName(body?.room);
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      const stub = env.ROOMS.get(id);

      const upstream = await stub.fetch("https://lamna-room.internal/state", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

      return new Response(upstream.body, {
        status: upstream.status,
        headers: jsonHeaders,
      });
    }

    if (url.pathname === "/api/action" && request.method === "POST") {
      let body;
      try { body = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
      const room = roomName(body?.room);
      if (!room) return json({ error: "room_required" }, 400);
      const id = env.ROOMS.idFromName(room);
      const upstream = await env.ROOMS.get(id).fetch("https://lamna-room.internal/action", {
        method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
      });
      return new Response(upstream.body, { status: upstream.status, headers: jsonHeaders });
    }

    if (url.pathname === "/api/events" && request.method === "GET") {
      const room = roomName(url.searchParams.get("room"));
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      const stub = env.ROOMS.get(id);
      return stub.fetch("https://lamna-room.internal/events");
    }

    if (url.pathname === "/api/room" && request.method === "GET") {
      const room = roomName(url.searchParams.get("room"));
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      return env.ROOMS.get(id).fetch("https://lamna-room.internal/current");
    }

    // Everything else is the static Lamna app. Avoid stale HTML/JS/CSS on iPhone Safari after updates.
    const assetResponse = await env.ASSETS.fetch(request);
    const headers = new Headers(assetResponse.headers);
    if (/\.(?:html|js|css)$/i.test(url.pathname) || !url.pathname.includes(".")) {
      headers.set("cache-control", "no-cache, no-store, must-revalidate");
      headers.set("pragma", "no-cache");
      headers.set("expires", "0");
    }
    return new Response(assetResponse.body, {status: assetResponse.status, statusText: assetResponse.statusText, headers});
  },
};

export class LamnaRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.streams = new Set();
  }

  broadcast(payload) {
    const message = `data: ${JSON.stringify(payload)}\n\n`;
    for (const controller of [...this.streams]) {
      try { controller.enqueue(new TextEncoder().encode(message)); }
      catch { this.streams.delete(controller); }
    }
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (url.pathname === "/current") {
      const payload = await this.state.storage.get("payload");
      return json(payload || { empty: true });
    }

    if (url.pathname === "/state" && request.method === "POST") {
      let incoming;
      try {
        incoming = await request.json();
      } catch {
        return json({ error: "invalid_json" }, 400);
      }

      const payload = {
        room: String(incoming.room || ""),
        game: incoming.game ?? null,
        action: incoming.action || "update",
        source: incoming.source || "",
        state: incoming.state || {},
        updatedAt: Date.now(),
      };

      // Persist the latest authoritative game snapshot.
      await this.state.storage.put("payload", payload);

      // Fan out instantly to all connected browsers in this room.
      this.broadcast(payload);

      return json({ ok: true, room: payload.room, updatedAt: payload.updatedAt });
    }

    if (url.pathname === "/action" && request.method === "POST") {
      let incoming;
      try { incoming = await request.json(); } catch { return json({ error: "invalid_json" }, 400); }
      const payload = await this.state.storage.get("payload");
      if (!payload || !payload.state) return json({ error: "room_empty" }, 404);
      if (Number(payload.game) !== Number(incoming.game)) return json({ error: "wrong_game" }, 409);
      const st = payload.state;
      const data = incoming.data || {};
      const rd = st.roundData && typeof st.roundData === "object" ? st.roundData : {};
      const rk = String(data.roundKey || "");
      if (rd.roundKey && rk && rd.roundKey !== rk) return json({ error: "stale_round" }, 409);
      if (rk) rd.roundKey = rk;
      const pid = String(data.playerId || "");
      switch (String(incoming.type || "")) {
        case "vote":
          rd.votes ||= {};
          if (pid && rd.votes[pid] === undefined) rd.votes[pid] = String(data.choice ?? "");
          break;
        case "actor_choice":
          if (rd.actorChoice === undefined) rd.actorChoice = String(data.choice ?? "");
          break;
        case "choice":
          rd.choices ||= {};
          if (pid && rd.choices[pid] === undefined) rd.choices[pid] = String(data.choice ?? "");
          if (Array.isArray(data.labels)) rd.labels = data.labels.slice(0, 8).map(String);
          break;
        case "answer_text":
          rd.answers ||= {};
          if (pid && rd.answers[pid] === undefined) rd.answers[pid] = String(data.text || "").slice(0, 120);
          if (Array.isArray(data.pair)) rd.pair = data.pair.map(String).slice(0, 2);
          break;
        case "confirm":
          rd.confirmations ||= {};
          if (pid) rd.confirmations[pid] = true;
          break;
        case "buzzer":
          if (!rd.claim && pid) rd.claim = { playerId: pid, at: Date.now() };
          break;
        case "team_claim":
          if (!rd.teamClaim) rd.teamClaim = { team: Number(data.team) === 2 ? 2 : 1, playerId: pid, at: Date.now() };
          break;
        case "survey_answer":
          if (!rd.surveyLast) rd.surveyLast = { team: Number(data.team) === 2 ? 2 : 1, text: String(data.text || "").slice(0, 80), at: Date.now() };
          break;
        case "duel_step": {
          const team = Number(data.team) === 2 ? 2 : 1;
          const turn = Number(rd.turnTeam || 1);
          if (team === turn && !rd.stoppedTeam) { rd.streak = Number(rd.streak || 0) + 1; rd.turnTeam = team === 1 ? 2 : 1; }
          break;
        }
        case "duel_stop": {
          const team = Number(data.team) === 2 ? 2 : 1;
          const turn = Number(rd.turnTeam || 1);
          if (team === turn && !rd.stoppedTeam) rd.stoppedTeam = team;
          break;
        }
        default:
          return json({ error: "unknown_action" }, 400);
      }
      st.roundData = rd;
      const next = { ...payload, action: `event:${incoming.type}`, source: incoming.source || "", state: st, updatedAt: Date.now() };
      await this.state.storage.put("payload", next);
      this.broadcast(next);
      return json({ ok: true, payload: next });
    }

    if (url.pathname === "/events" && request.method === "GET") {
      const self = this;
      const stream = new ReadableStream({
        async start(controller) {
          self.streams.add(controller);

          const latest = await self.state.storage.get("payload");
          const first = latest || { hello: true, updatedAt: Date.now() };
          controller.enqueue(
            new TextEncoder().encode(`data: ${JSON.stringify(first)}\n\n`)
          );

          // Keep-alive comment so proxies keep the SSE connection open.
          const keepAlive = setInterval(() => {
            try {
              controller.enqueue(new TextEncoder().encode(`: ping ${Date.now()}\n\n`));
            } catch {
              clearInterval(keepAlive);
              self.streams.delete(controller);
            }
          }, 20000);
        },
        cancel() {
          // A disconnected stream will also be removed on the next broadcast/ping.
        },
      });

      return new Response(stream, {
        headers: {
          "content-type": "text/event-stream; charset=utf-8",
          "cache-control": "no-cache, no-transform",
          "connection": "keep-alive",
          "access-control-allow-origin": "*",
          "x-accel-buffering": "no",
        },
      });
    }

    return json({ error: "not_found" }, 404);
  }
}
