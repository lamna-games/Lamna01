
const jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: jsonHeaders });
}

function roomName(value) {
  const room = String(value || "").trim().slice(0, 48);
  return /^[A-Z0-9_-]+$/i.test(room) ? room : "";
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/health") {
      return json({
        ok: true,
        backend: "cloudflare-workers-durable-objects",
        realtime: true,
        time: Date.now(),
      });
    }

    if (url.pathname === "/api/state" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "invalid_json" }, 400);
      }

      const room = roomName(body?.room);
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      const stub = env.ROOMS.get(id);

      const upstream = await stub.fetch("https://lamna-room.internal/state", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

      return new Response(upstream.body, {
        status: upstream.status,
        headers: jsonHeaders,
      });
    }

    if (url.pathname === "/api/events" && request.method === "GET") {
      const room = roomName(url.searchParams.get("room"));
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      const stub = env.ROOMS.get(id);
      return stub.fetch("https://lamna-room.internal/events");
    }

    if (url.pathname === "/api/room" && request.method === "GET") {
      const room = roomName(url.searchParams.get("room"));
      if (!room) return json({ error: "room_required" }, 400);

      const id = env.ROOMS.idFromName(room);
      return env.ROOMS.get(id).fetch("https://lamna-room.internal/current");
    }

    // Everything else is the static Lamna app.
    return env.ASSETS.fetch(request);
  },
};

export class LamnaRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.streams = new Set();
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (url.pathname === "/current") {
      const payload = await this.state.storage.get("payload");
      return json(payload || { empty: true });
    }

    if (url.pathname === "/state" && request.method === "POST") {
      let incoming;
      try {
        incoming = await request.json();
      } catch {
        return json({ error: "invalid_json" }, 400);
      }

      const payload = {
        room: String(incoming.room || ""),
        game: incoming.game ?? null,
        action: incoming.action || "update",
        state: incoming.state || {},
        updatedAt: Date.now(),
      };

      // Persist the latest authoritative game snapshot.
      await this.state.storage.put("payload", payload);

      // Fan out instantly to all connected browsers in this room.
      const message = `data: ${JSON.stringify(payload)}\n\n`;
      for (const controller of [...this.streams]) {
        try {
          controller.enqueue(new TextEncoder().encode(message));
        } catch {
          this.streams.delete(controller);
        }
      }

      return json({ ok: true, room: payload.room, updatedAt: payload.updatedAt });
    }

    if (url.pathname === "/events" && request.method === "GET") {
      const self = this;
      const stream = new ReadableStream({
        async start(controller) {
          self.streams.add(controller);

          const latest = await self.state.storage.get("payload");
          const first = latest || { hello: true, updatedAt: Date.now() };
          controller.enqueue(
            new TextEncoder().encode(`data: ${JSON.stringify(first)}\n\n`)
          );

          // Keep-alive comment so proxies keep the SSE connection open.
          const keepAlive = setInterval(() => {
            try {
              controller.enqueue(new TextEncoder().encode(`: ping ${Date.now()}\n\n`));
            } catch {
              clearInterval(keepAlive);
              self.streams.delete(controller);
            }
          }, 20000);
        },
        cancel() {
          // A disconnected stream will also be removed on the next broadcast/ping.
        },
      });

      return new Response(stream, {
        headers: {
          "content-type": "text/event-stream; charset=utf-8",
          "cache-control": "no-cache, no-transform",
          "connection": "keep-alive",
          "access-control-allow-origin": "*",
          "x-accel-buffering": "no",
        },
      });
    }

    return json({ error: "not_found" }, 404);
  }
}
